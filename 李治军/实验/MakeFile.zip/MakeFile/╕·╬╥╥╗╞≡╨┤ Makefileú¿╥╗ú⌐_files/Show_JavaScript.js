
csdn_ad_url = 'http://ggmm.csdn.net/GGMM/ShowJavaScriptGGMM.aspx?show=true';

function csdn_append_url(param, value) {
  if (value) {
    window.csdn_ad_url += '&' + param + '=' + value;
  }
}

function quoted(str) {
  return (str != null) ? '"' + str + '"' : '""';
}

function csdn_show_ad() 
{
	var w = window;
	csdn_append_url('position',w.csdn_AD_Position_GroupID);
	csdn_append_url('url',w.csdn_page_url);
	csdn_append_url('time',w.csdn_AD_Demo_Time);
	csdn_append_url('CharSet',w.csdn_AD_CurrPage_CharSet);
	csdn_append_url('ShowType',w.csdn_AD_ShowDefaultAD_OR_ShowBlank);
	
    document.write('<scr' + 'ipt language="JavaScript1.1"' +
                   ' src=' + quoted(w.csdn_ad_url) +
                   '></scr' + 'ipt>');
}

csdn_show_ad() ;
