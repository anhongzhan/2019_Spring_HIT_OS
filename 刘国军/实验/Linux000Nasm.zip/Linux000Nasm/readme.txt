1. Windows下，更改完源代码，可直接运行makefile.bat，即可完成编译与链接操作，生成Image.bin文件，编译细节可详见里面内容。
1.1 补充说明：cat.exe和HBIN.exe为Windows下所用链接二进制文件的应用程序，确保与源文件同目录。否则，则需将其加入系统路径。
1.2 运行可双击Linux000Nasm.bxrc
1.3 调试可双击Linux000Nasm.bat

2. Linux下，更改完源代码，命令行下，可直接运行sh makefile.sh，即可完成编译与链接操作，生成Image.bin文件。
2.1 运行可双击Linux000Nasm.bxrc
2.2 调试可双击sh Linux000Nasm.sh


by Dr. GuoJun LIU
Last Updated On 2014-10-25
