java -jar peter-bochs-debugger20130922.jar bochsdbg -q -f Image.bxrc
